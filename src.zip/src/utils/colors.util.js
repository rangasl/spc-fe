
const colors = [
    "#3aa1ff",
    "#322e2f",
    "#e2d810",
    "#d72631",
    "#12a4d9",
    "#a2d5c6",
    "#077b8a",
    "#5c3c92",
    "#0d1137"
];

export default colors;